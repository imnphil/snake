#include <iostream>
#include "ReadInput.h"
#include "Threads.h"
#include "Snake.h"
#include <thread>
#include <vector>
#include <time.h>


using namespace std;
bool hello = true;
Snake BrdSet;
Thread Sneko;
ReadInput inputRead;

void charCall() {
    while (hello){
        BrdSet.input = inputRead.collectInput();
        if (BrdSet.input == 'q' || BrdSet.input == 'Q')
            break;
            
    }
}

    void snakePrint(){
       while (hello){
            Sneko.Sleep(1);
            
            system("stty cooked");
            
            if (BrdSet.input == 'q' || BrdSet.input == 'Q')
                break;
                
            BrdSet.movement(BrdSet.input);
            
            BrdSet.clrScreen();
            
            cout << "Your score is : " << BrdSet.snekoScore() <<  endl;
            
            hello = BrdSet.draw();
            if (hello == false)
                BrdSet.GameOver();
            system("stty raw");
            
        }
    }
int main() 
{
    srand(time(NULL));
    BrdSet.newBody();
    
    thread first (charCall);     // spawn new thread that calls input()
    thread second (snakePrint);  // spawn new thread that calls snakePrint(0)
    cout << "Press w,a,s,d to begin.";

    // synchronize threads:
    first.join();                // pauses until first finishes
    second.join(); 
    return 0;
}


//g++ *.cpp -o main.out -pthread -std=c++11 && ./main.out
//echo *.cpp