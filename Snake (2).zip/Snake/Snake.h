#ifndef SNAKE_H
#define SNAKE_H

#include <iostream>



class Snake {
    public:
        void movement(char input);
        bool draw();
        int snekoScore();
        void clrScreen();
        void bodied();
        char input;
        int getX();
        int getY();
        void newBody();
        void GameOver();
        
    private:
    
        int x = 13, y = 13, i = 0, q = 0, score = 0,
        h = 13, o = 23;
        char grid[30][60];
        char whtSpace = ' ';
        int direction = 5;
        int bonusBody = 0;
    };




class Body {
    public:
    
    Body(int xCord, int yCord);
    int getX();
    int getY();
    void changeX(bool updown);
    void changeY(bool updown);
    void follow(int count);
    int getlastX();
    int getlastY();
    void setLast(int count);
    
    
    private:
    
    int x, y;
    int lastX, lastY;
    char piece;
};
#endif