#include <iostream>
#include <thread>  
#include <unistd.h>
#include <vector>
#include "Snake.h"

using namespace std;
bool hi = true;
Snake bdy;
vector <Body> parts;
 void Snake::movement(char input){
          if((input == 'w'|| input == 'W')&& direction != 3 )
            direction = 1;
          
          else 
          if((input == 'a'|| input == 'A')&& direction != 2 )
            direction = 4;
          
          else
          if((input == 's'|| input == 'S')&& direction != 1 )
            direction = 3;
          
          else
          if((input == 'd'|| input == 'D')&& direction != 4 )
            direction = 2;
            
            
            
            
          if(direction == 1){
            x--;
            parts[0].changeX(1);
          }
          else 
          if(direction == 4){
            y--;
            parts[0].changeY(1);
          }
          else
          if(direction == 3){
            x++;
            parts[0].changeX(0);
          }
          else
          if(direction == 2){
            y++;
            parts[0].changeY(0);
          }
        
        for (int count = 0; count < parts.size(); count++){
            if (count != 0)
            parts[count].follow(count);
                }
 }
 
 
 bool Snake::draw(){
    for (int i = 0; i < 29; i++){
     for (int q = 0; q < 60; q++){
        if (x < 1)return false;
        if (y < 1)return false;
        if (x > 26)return false;
        if (y > 57)return false;
        grid[i][q] = whtSpace;
        if (h == i || o == q)
            grid[h][o] = '*';
        if (i == 27 || i == 0)  
            grid[i][q] = '|';
        if(q == 0 || q == 59)
            grid[i][q] = '_';
            
            
        for ( int count = 0; count < parts.size(); count++){
            if (grid[parts[0].getX()][parts[0].getY()] == '-') return false;
            if (count == 0){
                if( direction == 2)
                    grid[parts[count].getX()][parts[count].getY()] = '>';
                else 
                if ( direction == 3)
                    grid[parts[count].getX()][parts[count].getY()] = 'v';
                else
                if( direction == 4)
                    grid[parts[count].getX()][parts[count].getY()] = '<';
                else
                if( direction == 1)
                    grid[parts[count].getX()][parts[count].getY()] = '^';
                else
                grid[parts[count].getX()][parts[count].getY()] = 'O';
            }
            else
            grid[parts[count].getX()][parts[count].getY()] = '-';
            
        }
     }
    }
    
    
    
    
    for (int i = 0; i < 29; i++){
        cout << endl;
    for (int q = 0; q < 60; q++){
        cout << grid[i][q] << " ";
    }
    }
if (grid [x][y] == grid[h][o] ){
    h = (rand() % 26) + 1;
    o = (rand() % 57) + 1;
    score++;
    bdy.newBody();
    bonusBody = bonusBody + 2;
} else if (bonusBody > 0){
    bdy.newBody();
    bonusBody--;
}
return true;
}
 int Snake::snekoScore(){
    return score;
 }
 
 void Snake::clrScreen(){
    for (int p = 0; p < 40; p++){ 
        cout << endl;
    }
 }
 
 int Snake::getX(){
     return x;
 }
 int Snake::getY(){
     return y;
 }
  void Snake::newBody(){
    Body segment (x,y);
    parts.push_back(segment);
    }
    
 void Snake::GameOver(){
    for (int p = 0; p < 40; p++){ 
        cout << endl;
    }
    cout << "   _____                         ____"<< endl <<
            "  / ____|                       / __ | " << endl <<
            " | |  __  __ _ _ __ ___   ___  | |  | |_   _____ _ __" << endl << 
            " | | |_ |/ _` | '_ ` _ | / _ | | |  | || | / / _ | '__|" << endl << 
            " | |__| | (_| | | | | | |  __/ | |__| || V /  __/ |" << endl <<
            "  |_____||__,_|_| |_| |_||___|  |____/  |_/ |___|_|" << endl;
 }
 
 
 
 
 
 
 
  void Body::changeX(bool updown){
      lastX = x;
      lastY = y;
    if (updown)
        x--;
    else
        x++;
  }
 
  void Body::changeY(bool updown){
      lastX = x;
      lastY = y;
    if (updown)
        y--;
    
    else
        y++;
}
 
 
 Body::Body(int xCord, int yCord){
    x = xCord;
    y = yCord;
 }
 
 int Body::getX(){
     return x;
 }
 int Body::getY(){
     return y;
 }
 int Body::getlastX(){
     return lastX;
 }
 int Body::getlastY(){
     return lastY;
 }
 
 void Body::follow(int count){
     lastX = x;
     lastY = y;
    x = parts[count - 1].getlastX();
    y = parts[count - 1].getlastY();
 }