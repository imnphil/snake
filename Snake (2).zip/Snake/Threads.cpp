#include <iostream>
#include <thread>  
#include <unistd.h>
#include "Threads.h"

void Thread::Sleep(float s){
    int sec = int(s*100000); 
    usleep(sec); 
}