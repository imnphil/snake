#include <iostream>
#include <stdio.h>
#include "ReadInput.h"
using namespace std;

char ReadInput::collectInput (){
        system("stty raw"); 
            inputCh = getchar(); 
        system("stty cooked"); 
        return inputCh;
}

