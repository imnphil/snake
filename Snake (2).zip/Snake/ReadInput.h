#ifndef READINPUT_H
#define READINPUT_H
#include <iostream>


class  ReadInput {
    public :
        char collectInput();
    private:
        char inputCh;
};

#endif
