#ifndef THREADS_H
#define THREADS_H
#include <iostream>


class  Thread {
    public: 
        void Sleep(float s);
        
};

#endif